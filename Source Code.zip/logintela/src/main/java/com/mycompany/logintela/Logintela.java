/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.logintela;

/**
 *
 * @author 82410835
 */
public class Logintela {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
